package Ex52;

	public class Produto {
	public int id;
	public String descricao;
	public double valor;
	public double quantidade;
}
