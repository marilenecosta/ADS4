package Ex52;

import java.util.Scanner;

public class Programa {

//Crie uma classe conforme o Diagrama de Classe (UML). 
//Crie um programa que utilize essa classe para cadastrar 
//10 produtos em uma lista de produtos. 
//Ao final exibir apenas os produtos cujo valor é 
//menor do que 100 reais.
	
public static void main(String[] args) {

Scanner ler = new Scanner(System.in);

//Cria um array contendo 10 posições para armazenar objetos
	Produto[] listaProdutos = new Produto[10];

for (int i=0; i<=9; i++) {
	
// Instancia (cria) o objeto
	Produto p = new Produto();

// Popula o objeto (preenche os atributos do objetos)
	System.out.printf("Digite o id do produto: ");
	p.id = ler.nextInt();
	
	System.out.printf("Digite a descrição do produto: ");
	p.descricao = ler.next();
	
	System.out.printf("Digite o valor do produto: ");
	p.valor = ler.nextDouble();
	
	System.out.printf("Digite a quantidade do produto: ");
	p.quantidade = ler.nextDouble();
	
// Adiciona o objeto no array "listaProdutos"
	listaProdutos[i] = p;
}
for (int i=0; i<=9; i++) {
	if (listaProdutos[i].valor < 100) {
		
	System.out.printf("\nProduto %d criando com sucesso (Descrição: %s, Valor: %.2f, Quantidade: %.0f)!!!", listaProdutos[i].id, listaProdutos[i].descricao, listaProdutos[i].valor, listaProdutos[i].quantidade); 
	}
	
	}

	} 

}
