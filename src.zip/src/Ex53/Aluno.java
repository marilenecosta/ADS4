package Ex53;

	public class Aluno {
	public String RA;
	public String Nome;
	public String Periodo;
	public String Materias;
}

