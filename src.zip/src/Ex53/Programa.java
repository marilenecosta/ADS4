package Ex53;

import java.util.Scanner;

public class Programa {

    public static void main(String[] args) {
        
         Aluno [] listaAluno = new Aluno[5];
         String temp=" ";
         
         Scanner ler = new Scanner (System.in);
            
             for (int i=0; i<5; i++) {
                 
             Aluno a = new Aluno();
             
             System.out.printf("Digite o RA: ");
             a.RA = ler.next();
             
             System.out.printf("Digite o nome: ");
             a.Nome = ler.next();
             
            do
             {
                 System.out.printf("Digite o periodo (MANHÃ | TARDE | NOITE): ");
                 temp = ler.next();
                 a.Periodo = temp;
                 
                 
             } while (temp == "MANHÃ" && temp == "TARDE" && temp == "NOITE" );
             
             for (int j=0;j<6;j++)
           {
             System.out.printf("Digite as iniciais das materias: ");
             a.Materias = ler.next();
           }
             
             System.out.printf("\n");
             
             listaAluno [i] = a;
             
             }
         
         
         for (int k=0; k<5; k++)
         {
             if(listaAluno[k].Periodo .equals("NOITE"))        
             {    
             System.out.printf("\nRA: %s \nNome: %s \nPeriodo: %s", listaAluno[k].RA, listaAluno[k].Nome, listaAluno[k].Periodo);
             }    
         }    
     }    
 }

