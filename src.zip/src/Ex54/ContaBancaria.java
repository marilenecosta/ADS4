package Ex54;

public class ContaBancaria {
	
	String agencia;
	String numero;
	double saldo;
	
	
	ContaBancaria(){}
	
	ContaBancaria(String agencia,String numero, double saldo){
		this.agencia = agencia;
		this.numero = numero;
		this.saldo = saldo;

	}
}


