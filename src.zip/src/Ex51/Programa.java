package Ex51;

import java.util.Scanner;

public class Programa {


//Crie uma classe conforme o Diagrama de Classe (UML). 
//Crie um programa que utilize essa classe para cadastrar
//5 clientes em uma lista de clientes. 
//Ao final exibir apenas os clientes que tem mais de 18 anos.
	
	public static void main(String[] args) {
	Scanner ler = new Scanner(System.in);
	
// Cria um array contendo 10 posições para armazenar objetos	
Cliente[] listaClientes = new Cliente[5];

for (int i=0; i<=4; i++) {
	
// Instancia (cria) o objeto
	Cliente c = new Cliente();
	
// Popula o objeto (preenche os atributos do objetos)	
	System.out.printf("Digite o o id do Cliente: ");
	c.id = ler.nextInt();
	
	System.out.printf("Digite o nome do Cliente: ");
	c.nome = ler.next();
	
	System.out.printf("Digite a idade do Cliente: ");
	c.idade = ler.nextInt();
	
	System.out.printf("Digite o e-mail do Cliente: ");
	c.email = ler.next();
	
// Adiciona o objeto no array "listaClientes"	
	
	listaClientes[i] = c;
}

for (int i=0; i<=4; i++) {
	if (listaClientes[i].idade >= 18) {
	System.out.printf("\nCliente %d cadastrado com  sucesso (Nome: %s, Idade: %d, E-mail: %s)!!!", listaClientes[i].id, listaClientes[i].nome, listaClientes[i].idade, listaClientes[i].email);	
	}
}
	}

}