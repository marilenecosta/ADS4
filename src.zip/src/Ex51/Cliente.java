package Ex51;

public class Cliente {
	public int id;
	public String nome;
	public int idade;
	public String email;
}
