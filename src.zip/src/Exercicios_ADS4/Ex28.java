package Exercicios_ADS4;

import java.util.Scanner;

public class Ex28 {
	
	//Escreva um algoritmo que leia três valores inteiros e diferentes e mostre-os em ordem crescente.

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
				
				int A, B, C;
				
				System.out.printf("Digite o PRIMEIRO valor: ");
				A = ler.nextInt();
				
				System.out.printf("Digite o SEGUNDO valor: ");
				B = ler.nextInt();
				
				System.out.printf("Digite o TERCEIRO valor: ");
				C = ler.nextInt();
				
				if (A < B && B < C) {
					System.out.printf("Ordem Crescente: %d, %d, %d.", A, B, C);
				}else if (A < C && C < B) {
					System.out.printf("Ordem Crescente: %d, %d, %d.", A, C, B);
				}else if (B < A && A < C) {
					System.out.printf("Ordem Crescente: %d, %d, %d.", B, A, C);
				}else if (B < C && C < A) {
					System.out.printf("Ordem Crescente: %d, %d, %d.", B, C, A);
				}else if (C < A && A < B) {
					System.out.printf("Ordem Crescente: %d, %d, %d.", C, A, B);
				}else if (C < B && B < A) {
					System.out.printf("Ordem Crescente: %d, %d, %d.", C, B, A);
				}

	}

}
