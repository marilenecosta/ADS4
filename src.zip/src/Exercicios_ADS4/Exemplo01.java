package Exercicios_ADS4;

public class Exemplo01 {

	public static void main(String[] args) {
		System.out.print("Olá mundo!");
	}
}
