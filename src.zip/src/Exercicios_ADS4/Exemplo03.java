package Exercicios_ADS4;

import java.util.Scanner;

public class Exemplo03 {

	public static void main(String[] args) {
		
		Scanner ler = new Scanner(System.in);
		
		double nota;
		String nome;
					
		System.out.printf("Informe o seu nome: ");
		nome = ler.nextLine();
		
		System.out.printf("Informe a nota da P1: ");
		nota = ler.nextDouble();
		
		System.out.printf("%s, tirou %.2f na P1", nome, nota);
	}
	
}
