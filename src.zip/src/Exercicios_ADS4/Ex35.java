package Exercicios_ADS4;

import java.util.Scanner;

public class Ex35 {
	
	//Entrar via teclado com um valor qualquer. Travar a digitação, no sentido de aceitar somente valores positivos.
	//Após a digitação, exibir a tabuada do valor solicitado, no intervalo de um a dez.

	public static void main(String[] args) {
	     Scanner ler = new Scanner(System.in);
			
			int A, Y;
			
			do{	
			System.out.printf("Digite um VALOR POSITIVO: ");
			A = ler.nextInt();
			}
			while(A < 0);
			System.out.printf("< Tabuada do %d >-5", A);
			for(Y=1; Y<=10; Y++) {			
				System.out.printf("\n %d X %d = %d", Y, A,(A * Y));
			}

	}

}
