package Exercicios_ADS4;

import java.util.Scanner;

public class Ex08 {
	
	//Entrar via teclado, com dois valores distintos. Exibir o maior deles.

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		
		double valor1, valor2;
		
		System.out.print("Digite o primeiro valor: ");
		valor1 = ler.nextDouble();
		
		System.out.print("Digite o segundo valor: ");
		valor2 = ler.nextDouble();
				
		if (valor1>valor2) {
			System.out.printf("O valor é: %.2f", valor1);
		}else {
			System.out.printf("O valor é: %.2f", valor2);
		
		}
	
	}

}


