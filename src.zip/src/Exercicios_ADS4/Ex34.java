package Exercicios_ADS4;

public class Ex34 {
	
	//Exibir a tabuada do número cinco no intervalo de um a dez.

	public static void main(String[] args) {
		for(int x = 1; x <= 10; x++) {
			System.out.printf("\n%d X 5 = %d", x, (x*5));
		}

	}

}
