package Exercicios_ADS4;

import java.util.Scanner;

public class Ex41 {
	
	//Calcular e exibir a soma dos “N” primeiros valores da seqüência abaixo. O valor “N” será digitado, 
	//deverá ser positivo, mas menor que cem. Caso o valor não satisfaça a restrição, enviar mensagem de erro e solicitar 
	//o valor novamente. A seqüência: 2, 5, 10, 17, 26, ....

	public static void main(String[] args) {
		
		Scanner ler = new Scanner(System.in);
		int Soma = 0, Ln = 2, N = 0, Seq = 0;
		do {
			System.out.println("\nDigite a quantidade de vezes da sequencia até a soma (0 > N < 100): ");
			N = ler.nextInt();
			
		}
		while(N >= 100 || N < 1);
		for(int X = 0; X < N; X++) {
				Seq += Ln;
				Soma+= Seq;
				Ln = 3 + 2 * X;
		}
		System.out.printf("\nA soma dos %d primeiros numeros da sequência é: %d", N, Soma);
	}

}
