package Exercicios_ADS4;

import java.util.Scanner;

public class Ex31 {
	
	//Criar uma rotina de entrada que aceite somente um valor positivo

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		
		int A;
		
		do{	
		System.out.printf("Digite um valor POSITIVO: ");
		A= ler.nextInt();
		}
		while(A < 0);

	}

}
