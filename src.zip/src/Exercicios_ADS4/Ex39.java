package Exercicios_ADS4;

import java.util.Scanner;

public class Ex39 {
	
	//Exibir os trinta primeiros valores da série de Fibonacci. A série: 1, 1, 2, 3, 5, 8, ...


	public static void main(String[] args) {
		int Soma = 0, N1 = 1, N2 = 0;
		System.out.printf("Sequência de FINONACCI (Os 30 primeiros valores).\n ");
		for(int X = 0; X < 30; X++) {
			Soma = N1 + N2;
			
			System.out.printf("\n%d", N1);
			N2 = N1;
			N1 = Soma;

	}

	}

}
