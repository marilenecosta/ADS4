package Exercicios_ADS4;

import java.util.Scanner;

public class Ex38 {
	
	//Exibir a soma dos números inteiros positivos do intervalo de um a cem.

	public static void main(String[] args) {
		
		int Soma = 0, Intervalo = 0;
		for(int X = 1; X <= 100; X++) {
			Soma = X + Intervalo;
			System.out.printf("\n%d + %d = %d", X, Intervalo, Soma);
			Intervalo = Soma;
		}
		System.out.printf("\nA A Soma dos intervalos entre 1 e 100 é = %d", Soma);
	}

}
