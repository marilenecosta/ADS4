package Exercicios_ADS4;

import java.util.Scanner;

public class Ex36 {
	
	//Entrar via teclado com um valor (X) qualquer. Travar a digitação, no sentido de aceitar somente valores positivos. 
	//Solicitar o intervalo que o programa que deverá calcular a tabuada do valor digitado, sendo que o segundo valor (B), 
	//deverá ser maior que o primeiro (A), caso contrário, digitar novamente somente o segundo. Após a validação dos dados, 
	//exibir a tabuada do valor digitado, no intervalo decrescente, ou seja, a tabuada de X no intervalo de B para A.

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		
		int X, A, B;
		
		do {
			System.out.printf("Digite um NÚMERO POSITIVO: ");
			X = ler.nextInt();
		}
		while(X <= 0);
		
		System.out.printf("Digite o PRIMEIRO NÚMERO: ");
		A = ler.nextInt();
		
		do {
			System.out.printf("Digite o SEGUNDO NÚNERO (Ele tem que ser MAIOR que o PRIMEIRO): ");
			B = ler.nextInt();
		}
		while(B <= A);
		
		for(; B >= A; B--) {
			System.out.printf("\n%d X %d = %d", B, X, (B * X));
		}

	}

}
