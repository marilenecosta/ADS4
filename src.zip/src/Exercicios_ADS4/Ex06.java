package Exercicios_ADS4;

import java.util.Scanner;

public class Ex06 {
	
	//Entrar via teclado com o valor da cotação do dólar e uma certa quantidade de dólares. 
	//Calcular e exibir o valor correspondente em Reais (R$).

	public static void main(String[] args) {
	
		Scanner ler = new Scanner(System.in);
		
		double dolar, quantidade, real;
		
		System.out.printf("Entre com o valor da cotação do dolar: ");
		dolar = ler.nextDouble();
		
		System.out.printf("Entre com a quantidade de doláres: ");
		quantidade = ler.nextDouble();
		
		real = quantidade * dolar;
		
		System.out.printf("O valor correspondente em reais é de: %.2f", real);
		
	}

}