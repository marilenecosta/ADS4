package Exercicios_ADS4;

import java.util.Scanner;

public class Ex45 {
	
	//Entrar via teclado com “N” valores quaisquer. O valor “N” (que representa a quantidade de números) será digitado, deverá ser positivo, 
	//mas menor que vinte. Caso a quantidade não satisfaça a restrição, enviar mensagem de erro e solicitar o valor novamente. Após a digitação dos “N” 
	//valores, exibir:
	//a) O maior valor;
	//b) O menor valor;
	//c) A soma dos valores;
	//d) A média aritmética dos valores;
	//e) A porcentagem de valores que são positivos;
	//f) A porcentagem de valores negativos;


	public static void main(String[] args) {
		
		Scanner ler = new Scanner(System.in);
		
		int Num;
		double Numero, Maior = 0, Menor = 0, Media = 0, PercentualNegativo = 0, Soma = 0;
		
		System.out.printf("Quantidades de NÚMEROS: ");
		Num = ler.nextInt();
		
		while(Num < 1 || Num > 20) {
			
			System.out.printf("NÚMERO INVÁLIDO! Insira um NÚMERO entre 1 e 20: ");
			Num = ler.nextInt();
			
		}
		for(int x = 0; x < Num; x++) 
		{
			System.out.printf("Insira um NÚMERO: ");
			Numero = ler.nextDouble();
			if(Numero > Maior || x == 0) {
				
				Maior = Numero;
				
			}
			
			if(Numero < Menor || x == 0) {
				
				Menor = Numero;
				
			}
			
			if(Numero < 0) {
				
				PercentualNegativo += 1;
				
			}
			
			Soma += Numero; 
		}
		
		Media = Soma / Num;
		
		System.out.printf("O MAIOR valor é: %.2f\n", Maior);
		System.out.printf("O MENOR valor é: %.2f\n", Menor);
		System.out.printf("A SOMA dos valores é: %.2f\n", Soma);
		System.out.printf("A MÉDIA é: %.2f\n", Media);
		System.out.printf("A porcentagem dos valores POSITIVOS é: %.2f%%\n", ((Num - PercentualNegativo) * 100) / Num);
		System.out.printf("A porcentagem dos valores NEGATIVOS é: %.2f%%\n", (PercentualNegativo * 100) / Num);
	}

}
