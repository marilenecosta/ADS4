package Exercicios_ADS4;

import java.util.Scanner;

public class Ex10 {

	//Entrar com dois valores quaisquer. Exibir o maior deles, se existir, caso contrário, 
	//enviar mensagem avisando que os números são idênticos.

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		
		double valor1, valor2;
		
		System.out.print("Digite o primeiro valor: ");
		valor1 = ler.nextDouble();
		
		System.out.print("Digite o segundo valor: ");
		valor2 = ler.nextDouble();
				
		if (valor1>valor2) {
			System.out.printf("O valor é: %.2f", valor1);
		}else {
			System.out.printf("O valor é: %.2f", valor2);
		
		}
	
	}

}
