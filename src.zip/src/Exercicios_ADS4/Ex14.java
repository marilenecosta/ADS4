package Exercicios_ADS4;

import java.util.Scanner;

public class Ex14 {

	//Entrar com o peso e a altura de uma determinada pessoa. 
	//Após a digitação, exibir se esta pessoa está ou não com seu peso ideal. Fórmula: peso/altura².

		public static void main(String[] args) {
			Scanner ler = new Scanner(System.in);
			
			double peso, altura, imc;
			
			System.out.printf("Digite o seu peso: ");
			peso = ler.nextDouble();
			
			System.out.printf("Digite a sua altura: ");
			altura = ler.nextDouble();
			
			imc = peso / (altura * altura);
			
			
			if (imc < 20) {
				System.out.printf("Você está ABAIXO do peso!!!");
			}else if (imc < 25){
				System.out.printf("PARABÉNS!!! Vocês está no peso IDEAL!!");
			}
			else {
				System.out.printf("CUIDADO!!! Vocês está acima do peso!!!");
			}

		}

	}
