package Exercicios_ADS4;

import java.util.Scanner;

public class Ex47 {
	
	//Calcular o fatorial de um valor que será digitado. Este valor não poderá ser negativo. Enviar mensagem de erro e solicitar o valor novamente, 
	//se necessário. Perguntar se o usuário deseja ou não fazer um novo cálculo, consistir a resposta em “S” ou “N”.
	//N! = N x N-1 x N-2 x N-3 x ....... x (N - (N-1))
	//Ex: 5! = 5 x 4 x 3 x 2 x 1 = 120

	public static void main(String[] args) {
		
		Scanner ler = new Scanner(System.in);
		
		Character Resposta;
		
		do {
			int N = 0, Total = 1;
			System.out.printf("Qual NÚMERO você deseja ver o FATORIAL?: ");
			N = ler.nextInt();
			while(N < 1) {
				
				System.out.printf("Valor INVÁLIDO! insira um NÚMERO MAIOR que 1: ");
				N = ler.nextInt();
				
			}
			
			for(int X = N; X > 0; X--) {
				
				Total *= X;
				
			}
			
			System.out.printf("O FATORIAL de %d é: %d\n", N, Total);
			System.out.printf("Deseja executar novamente? <S> <N>: ");
			Resposta = ler.next().charAt(0);
			
			while(Resposta != 's' && Resposta != 'S' && Resposta != 'n' && Resposta != 'N') {
				
				System.out.printf("Insira apenas as respostas <S> ou <N>\n");
				Resposta = ler.next().charAt(0);
				
			}
			
		}while(Resposta == 's' || Resposta == 'S');
		
		System.out.printf("PROGRAMA FINALIZADO!!!");

	}

}
