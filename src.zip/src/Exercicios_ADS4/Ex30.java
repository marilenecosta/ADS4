package Exercicios_ADS4;

import java.util.Scanner;

public class Ex30 {
	
	//Elabore um algoritmo que calcule o que deve ser pago por um produto, considerando o preço normal de etiqueta e a escolha da condição de pagamento. 
	//Utilize os códigos da tabela a seguir para ler qual a condição de pagamento escolhida e efetuar o cálculo adequado e exibir o valor a ser pago no final.

	//Código Condição de pagamento
	//1 	À vista em dinheiro ou cheque, recebe 10% de desconto
	//2 	À vista no cartão de crédito, recebe 15% de desconto
	//3 	Em duas vezes, preço normal de etiqueta sem juros
	//4 	Em quatro vezes, preço normal de etiqueta mais juros de 10%


	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
				
				double Preco, Pagamento;
				int Opcao;
				
				System.out.printf("Digite o valor do produto: ");
				Preco = ler.nextDouble();
				
				System.out.printf("Opções de PAGAMENTO:\n ");
				System.out.printf("<1> À vista, DINHEIRO ou CHEQUE\n ");
				System.out.printf("<2> À vista, CARTÃO DE CRÉDITO\n ");
				System.out.printf("<3> Em DUAS vezes\n ");
				System.out.printf("<4> Em QUATRO vezes\n ");
				System.out.printf("Digite a forma de PAGAMENTO:\n ");
				Opcao = ler.nextInt();
				
				switch(Opcao) {
					case 1:
						
						Pagamento = Preco - (Preco * 0.10);
						System.out.printf("O total do PAGAMENTO é de: %.2f.", Pagamento);
						
						break;
						
					case 2:
						
						Pagamento = Preco - (Preco * 0.15);
						System.out.printf("O total do PAGAMENTO é de: %.2f.", Pagamento);
						
						break;
						
					case 3:
						
						Pagamento = Preco;
						System.out.printf("O total do PAGAMENTO é de: %.2f.", Pagamento);
						
						break;
						
					case 4:
						
						Pagamento = Preco + (Preco * 0.1);
						System.out.printf("O total do PAGAMENTO é de: %.2f.", Pagamento);
						
						break;
						
					default:
						System.out.println("Opção Inválida!!!");
				}

	}

}
