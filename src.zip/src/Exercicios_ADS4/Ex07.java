package Exercicios_ADS4;

import java.util.Scanner;

public class Ex07 {
	
	//Entrar via teclado com o valor de cinco produtos. Após as entradas, digitar um valor referente ao 
	//pagamento da somatória destes valores. Calcular e exibir o troco que deverá ser devolvido.	

	public static void main(String[] args) {
		
		Scanner ler = new Scanner(System.in);
		
		double produto1, produto2, produto3, produto4, produto5, soma, pagamento, troco;
		
		System.out.print("Informe o valor do primeiro produto: ");
		produto1 = ler.nextDouble();
		
		System.out.print("Informe o valor do segundo produto: ");
		produto2 = ler.nextDouble();
		
		System.out.print("Informe o valor do terceiro produto: ");
		produto3 = ler.nextDouble();
		
		System.out.print("Informe o valor do quarto produto: ");
		produto4 = ler.nextDouble();
		
		System.out.print("Informe o valor do quinto produto: ");
		produto5 = ler.nextDouble();
		
		System.out.print("Digite o valor do pagamento dos produtos: ");
		pagamento = ler.nextDouble();
		 
		soma = produto1 + produto2 + produto3 + produto4 + produto5;
		troco = pagamento - soma;
		
		System.out.printf("O valor do troco é: %.2f", troco);

	}

}
