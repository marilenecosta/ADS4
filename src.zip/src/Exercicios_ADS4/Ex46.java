package Exercicios_ADS4;

import java.util.Scanner;

public class Ex46 {
	
	//Entrar via teclado com “N” valores quaisquer. O valor “N” (que representa a quantidade de números) será digitado, deverá ser positivo, 
	//mas menor que vinte. Caso a quantidade não satisfaça a restrição, enviar mensagem de erro e solicitar o valor novamente. 
	//Após a digitação dos “N” valores, exibir:
	//a) O maior valor;
	//b) O menor valor;
	//c) A soma dos valores;
	//d) A média aritmética dos valores;
	//e) A porcentagem de valores que são positivos;
	//f) A porcentagem de valores negativos;
	//Após exibir os dados, perguntar ao usuário se deseja ou não uma nova execução do programa. Consistir a resposta no 
	//sentido de aceitar somente “S” ou “N” e encerrar o programa em função dessa resposta.


	public static void main(String[] args) {
		
		Scanner ler = new Scanner(System.in);
		
		Character Resposta;
		
		do{
			int N = 0;
			double Numero, Maior = 0, Menor = 0, Media = 0, PercentualNegativo = 0, Soma = 0;
			System.out.printf("Quantidade de NÚMEROS: ");
			N = ler.nextInt();
			
			while(N < 1 || N > 20) {
				
				System.out.printf("ERRO!! Número INVÁLIDO! Insira um NÚMERO entre 1 e 20: ");
				N = ler.nextInt();
				
			}
			
			for(int X = 0; X < N; X++) {
				
				System.out.printf("Insira um NÚMERO: ");
				Numero = ler.nextDouble();
				
				if(Numero > Maior || X == 0) {
					
					Maior = Numero;
				}
				
				if(Numero < Menor || X == 0) {
					
					Menor = Numero;
					
				}
				
				if(Numero < 0) {
					
					PercentualNegativo += 1;
					
				}
				
				Soma += Numero;
				
			}
			
			Media = Soma / N;
			System.out.printf("O MAIOR valor é: %.2f\n", Maior);
			System.out.printf("O MENOR valor é: %.2f\n", Menor);
			System.out.printf("A SOMA dos valores é: %.2f\n", Soma);
			System.out.printf("A MÉDIA é: %.2f\n", Media);
			System.out.printf("A porcentagem dos valores POSITIVOS é: %.2f%%\n", ((N - PercentualNegativo) * 100) / N);
			System.out.printf("A porcentagem dos valores NEGATIVOS é: %.2f%%\n", (PercentualNegativo * 100) / N);
			System.out.printf("Deseja EXECUTAR o programa novamente?(S/N): ");
			Resposta = ler.next().charAt(0);
			while(Resposta != 's' && Resposta != 'S' && Resposta != 'n' && Resposta != 'N') 
			{
				System.out.printf("Insira apenas as respostas <S> ou <N>\n");
				Resposta = ler.next().charAt(0);
			}
		}
		while(Resposta == 's' || Resposta == 'S');
		System.out.printf("SISTEMA FINALIZADO!!!");

	}

}
