package Exercicios_ADS4;

import java.util.Scanner;

public class Ex33 {
	
	//Entrar via teclado com o sexo de determinado usuário, aceitar somente “F” ou “M” como respostas válidas.

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
				
				char Sexo;
		       
		        do {
		        	System.out.printf("Digite o SEXO, somente (F) para FEMININO e (M) para MASCULINO: ");
		            Sexo = ler.next().charAt(0);
		        }
		        while(Sexo != 'F' && Sexo != 'M');

	}

}
