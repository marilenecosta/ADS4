package Exercicios_ADS4;

import java.util.Scanner;

public class Ex23 {
	
	//Faça um algoritmo que leia os valores A, B, C e imprima na tela se a soma de A + B é menor que C.

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);

		double A, B, C, Soma;
		
		System.out.printf("Digite o valor de A: ");
		A = ler.nextDouble();
		
		System.out.printf("Digite o valor de B: ");
		B = ler.nextDouble();
		
		System.out.printf("Digite o valor de C: ");
		C = ler.nextDouble();
		
		Soma = (A + B);
		
		if(C < Soma)
		System.out.printf("A soma de A + B é = %.2f e o valor é MAIOR que C = %.2f. ", Soma, C);
		else
			System.out.printf("A soma de A + B é = %.2f e o valor é MENOR que C = %.2f. ", Soma, C);

	}

}
