package Exercicios_ADS4;

import java.util.Scanner;

public class Ex37 {
	
	//Exibir a tabuada dos valores de um a vinte, no intervalo de um a dez. Entre as tabuadas, solicitar que o usuário pressione uma tecla.


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner ler = new Scanner(System.in);
		int X, Y;
		for(X = 1; X <= 20; X++) {
			System.out.printf("\nTabuada do %d", X);
			for(Y = 1; Y <= 10; Y++) {
				System.out.printf("\n%d X %d = %d", Y, X, (Y * X));
			}
		System.out.println("\nAperte ENTER para continuar...");
		ler.nextLine();

		}
	}

}

