package Exercicios_ADS4;

import java.util.Scanner;

public class Ex02 {
	
	//Calcular e exibir a área de um quadrado, a partir do valor de sua aresta que será digitado.

	public static void main(String[] args) {
		
		Scanner ler = new Scanner(System.in);
		
		double lado, area;
		
		System.out.printf("Digite o lado do quadrado: ");
		lado = ler.nextDouble();
		
		area = lado * lado;
		System.out.printf("A área do quadrado é %.2f * %.2f é = %.2f", lado, lado, area);

	}

}
