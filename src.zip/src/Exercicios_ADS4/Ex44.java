package Exercicios_ADS4;

import java.util.Scanner;

public class Ex44 {
	
	//Entrar via teclado com dez valores positivos. Consistir a digitação e enviar mensagem de erro, se necessário. Após a digitação, exibir:
	//a) O maior valor;
	//b) A soma dos valores;
	//c) A média aritmética dos valores;


	public static void main(String[] args) {
		
		Scanner ler = new Scanner(System.in);
		
		float Numero = 0, Soma = 0, Maior = 0;
		
		for(int i = 1; i < 11; i++) {
			
			do {
				System.out.printf("Digite um valor positivo: ");
				Numero = ler.nextFloat();
			}while(Numero <= 0);
			
			if(i == 0 || Numero > Maior) {
				Maior = Numero;
			}
			
			Soma += Numero;
		}
		
		System.out.printf("A) Maior valor: %.2f\n", Maior);
		System.out.printf("B) Soma dos valores: %.2f\n", Soma);
		System.out.printf("C) Media dos valores: %.2f", (Soma / 10));

	}

}
