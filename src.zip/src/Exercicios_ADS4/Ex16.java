package Exercicios_ADS4;

import java.util.Scanner;

public class Ex16 {
	
	//Verificar se três valores quaisquer (A, B, C) que serão digitados formam ou não um triângulo retângulo. 
	//Lembre-se que o quadrado da hipotenusa é igual a soma dos quadrados dos catetos.


	public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);

        double A, B, C;

        System.out.printf("Digite um valor: ");
        A = ler.nextDouble();

        System.out.printf("Digite um valor: ");
        B = ler.nextDouble();

        System.out.printf("Digite um valor: ");
        C = ler.nextDouble();

        if ((A < B + C) && (B < A + C) && (C < A + B)) {
            if ((A * A) == ((B * B) + (C * C)) || (B * B) == ((A * A) + (C * C)) || (C * C) == ((B * B) + (A * A))) {
                System.out.printf("É um TRIÂNGULO RETÂNGULO!!!");
                
            } else
                System.out.printf("Não é um TRIÂNGULO RETÂNGULO!!!");

        } else {
            System.out.printf("Não é um TRIÂNGULO!!!");
        }
        
	}

}
