package Exercicios_ADS4;

import java.util.Scanner;

public class Ex17 {
	
	//Entrar com o peso, o sexo e a altura de uma determinada pessoa. Após a digitação, exibir se esta pessoa está ou não com seu peso ideal. 
	//Fórmula: peso/altura².

	public static void main(String[] args) {
	Scanner ler = new Scanner(System.in);
		
	double IMC, Peso, Altura;
	String Sexo;
	
	System.out.printf("Digite o sexo (M) para MASCULINO e (F) para FEMININO: ");
	Sexo = ler.nextLine();

	System.out.printf("Digite o peso: ");
	Peso = ler.nextDouble();
	
	System.out.printf("Digite a altura: ");
	Altura = ler.nextDouble();
	
	IMC = Peso/(Altura * Altura);
	
switch (Sexo){
	
	case "F":
		if(IMC<19) 
			System.out.printf("Seu imc e: %.2f. ATENÇÃO!!! Você está abaixo do peso!!!", IMC);
		else if(IMC<24) 
			System.out.printf("Seu imc e: %.2f. PARABÉNS!!! Você está no peso ideal!!!", IMC);
		else 
			System.out.printf("Seu imc e: %.2f. CUIDADO!!! Voce está acima do peso!!!", IMC);
		break;
		
	case "f":
		if(IMC<19) 
			System.out.printf("Seu imc e: %.2f. ATENÇÃO!!! Você está abaixo do peso!!!", IMC);
		else if(IMC<24) 
			System.out.printf("Seu imc e: %.2f. PARABÉNS!!! Você está no peso ideal!!!", IMC);
		else 
			System.out.printf("Seu imc e: %.2f. CUIDADO!!! Voce está acima do peso!!!", IMC);
		
	case "M":
		if(IMC<20) 
			System.out.printf("Seu imc e: %.2f. ATENÇÃO!!! Você está abaixo do peso!!!", IMC);
		 else if(IMC<25) 
			System.out.printf("Seu imc e: %.2f. PARABÉNS!!! Você está no peso ideal!!!", IMC);
		else 
			System.out.printf("Seu imc e: %.2f. CUIDADO!!! Voce está acima do peso!!!", IMC);
		break;
		
	case "m":
		if(IMC<20) 
			System.out.printf("Seu imc e: %.2f. ATENÇÃO!!! Você está abaixo do peso!!!", IMC);
		 else if(IMC<25) 
			System.out.printf("Seu imc e: %.2f. PARABÉNS!!! Você está no peso ideal!!!", IMC);
		else 
			System.out.printf("Seu imc e: %.2f. CUIDADO!!! Voce está acima do peso!!!", IMC);
		break;
        }

	}

}
