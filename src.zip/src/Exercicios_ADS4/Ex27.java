package Exercicios_ADS4;

import java.util.Scanner;

public class Ex27 {
	
	//Faça um algoritmo que leia uma variável e some 5 caso seja par ou some 8 caso seja ímpar, imprimir o resultado desta operação.

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
				
				int Valor, Resultado;
				
				System.out.printf("Digite qualquer VALOR: ");
				Valor = ler.nextInt();
				
				if(Valor%2==0) {
					Resultado = (Valor + 5);
					System.out.printf("O Resultado é: %d", Resultado);
				}else {
					Resultado = (Valor + 8);
					System.out.printf("O Resultado é: %d", Resultado);
				}

	}

}
