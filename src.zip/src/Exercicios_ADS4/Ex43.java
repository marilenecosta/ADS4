package Exercicios_ADS4;

import java.util.Scanner;

public class Ex43 {
	
	//Calcular e exibir a soma dos “N” primeiros valores da seqüência abaixo. O valor “N” será digitado, 
	//deverá ser positivo, mas menor que cinqüenta. Caso o valor não satisfaça a restrição, enviar mensagem de erro e solicitar o valor novamente.

	public static void main(String[] args) {
		
		Scanner ler = new Scanner(System.in);
		
		int Numero;
		float Soma = 0, P1 = 1;
		
		do {
		System.out.printf("Informe o tamanho da sequência (1 >= n < 50): ");
		Numero = ler.nextInt();
		
		}while(Numero < 1 || Numero > 49);
		
		for(int x = 0; x < Numero; x++) {
		
			P1 += 2 * x + 1;
			Soma += P1 / Math.pow((x + 1), 3);
			
		}
		
		System.out.printf("A soma dos primeiros %d números da sequência é: %.2f", Numero, Soma);

	}

}
