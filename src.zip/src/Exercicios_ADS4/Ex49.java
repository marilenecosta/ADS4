package Exercicios_ADS4;

import java.util.Scanner;

public class Ex49 {
	
	//Crie um programa que solicite que o usuário entre com dois números (inicial e final). 
	//Ao final o programa deverá apresentar o valor total da soma de todos os números do intervalo digitado pelo usuário.

	public static void main(String[] args) {
		
		Scanner ler = new Scanner(System.in);
		
		int Soma=0;
		
		System.out.printf("Insira o NNÚMERO INICIAL: ");
		int NumeroInicial = ler.nextInt();
		
		System.out.printf("Insira o NÚMERO FINAL: ");
		int NumeroFinal = ler.nextInt();
		
		while(NumeroFinal <= NumeroInicial) {
			
			System.out.printf("O NÚMERO FINAL deve ser MAIOR que o INICIAL: ");
			NumeroFinal = ler.nextInt();
			
		}
		
		for(int x = NumeroInicial; x <= NumeroFinal; x++)	{
			
			Soma+=x;
			
		}
		
		System.out.printf("A SOMA da sequencia de NÚMEROS entre %d e %d e: %d", NumeroInicial, NumeroFinal, Soma);

	}

}
