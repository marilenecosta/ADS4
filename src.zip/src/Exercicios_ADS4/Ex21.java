package Exercicios_ADS4;

import java.util.Scanner;

public class Ex21 {
	
	//Entrar via teclado com dois valores quaisquer. Após a digitação, exibir um seletor de opções (“menu”) com as seguintes opções: 
	//(Fazer esse exercício utilizando If..Else e/ou Case)
	//1 – Multiplicação
	//2 – Adição
	//3 – Divisão
	//4 – Subtração
	//5 – Fim de processo (sair do programa)
	//Solicitar uma opção por parte do usuário, verificar se é ou não uma opção válida (letras ou números) e processar a 
	//respectiva operação. Enviar mensagem de erro se a opção escolhida não existir no seletor. Encerrar o programa somente quando o usuário escolher 
	//a opção de finalização. Repare que a opção de número três é de divisão e o programa deverá enviar mensagem de erro,
	//(somente nesta opção) se o denominador for zero.


	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		
		int Opcao;
		double ValorA, ValorB, OP;
		
		do {
			System.out.printf("Digite qualquer valor: ");
			ValorA = ler.nextDouble();
			
			System.out.printf("Digite qualquer valor: ");
			ValorB = ler.nextDouble();
			
			System.out.printf("Menu de Opções:\n");
			System.out.printf("Opção <1> Multiplicação\n");
			System.out.printf("Opção <2> Adição\n");
			System.out.printf("Opção <3> Divisão\n");
			System.out.printf("Opção <4> Subtração\n");
			System.out.printf("Opção <5> Sair do Programa\n");
			System.out.printf("Digite a opcao desejada: ");
			Opcao = ler.nextInt();
			
			switch(Opcao) {
				case 1:					
					OP = ValorA * ValorB;
					System.out.printf("A MULTIPLICAÇÃO (X) entre: %.2f e %.2f =  %.2f.\n", ValorA, ValorB, OP);
					break;
					
				case 2:					
					OP = ValorA + ValorB;
					System.out.printf("A ADIÇÃO (+) entre: %.2f e %.2f = %.2f.\n", ValorA, ValorB, OP);
					break;
					
				case 3: 					
					if(ValorB == 0) {
						System.out.printf("Digite um denominador diferente de 0. (Inválido) \n");
						break;
					}
					
					OP = ValorA / ValorB;
					System.out.printf("A DIVISÃO (/) entre: %.2f e %.2f = %.2f.\n", ValorA, ValorB, OP);
					break;
					
				case 4:
					
					OP = ValorA - ValorB;
					System.out.printf("A SUBTRAÇÃO (-) entre: %.2f e %.2f = %.2f.\n", ValorA, ValorB, OP);
					break;
					
				case 5:					
					System.exit(0);					
					break;
					
				default:
					System.out.printf("Opcao inválida. Escolha um número válido.\n");
			}
			
		}while(Opcao!=5);

	}

}
