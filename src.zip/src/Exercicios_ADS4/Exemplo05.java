package Exercicios_ADS4;

import java.util.Scanner;

public class Exemplo05 {

	public static void main(String[] args) {

		Scanner ler = new Scanner(System.in);
		
		double alt, peso, imc;
		
		System.out.printf("Digite a sua altura: ");
		alt = ler.nextDouble();
		
		System.out.printf("Digite o seu peso: ");
		peso = ler.nextDouble();
		
		imc = peso / (alt *alt);
		
		if (imc < 20) {
			System.out.printf("Abaixo do peso!");
		}else if(imc < 25) {
			System.out.printf("Peso Ideal");
		}
		else {
			System.out.printf("Acima do peso!");
		}
	}
}
