package Exercicios_ADS4;

import java.util.Scanner;

public class Ex25 {
	
	//Faça um algoritmo para receber um número qualquer e informar na tela se é par ou ímpar. Utilize o operador %

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
				
				int Valor;
				
				System.out.printf("Digite qualquer VALOR: ");
				Valor = ler.nextInt();
				
				if(Valor%2==0) {
					System.out.printf("O valor digitado é PAR!!! ");
				}else {
					System.out.printf("O valor digitado é ÍMPAR!!! ");
				}

	}

}
