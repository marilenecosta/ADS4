package Exercicios_ADS4;

import java.util.Scanner;

public class Ex05 {
	
	//Entrar via teclado com o valor de uma temperatura em graus Celsius, calcular e exibir sua temperatura
	//equivalente em Fahrenheit

	public static void main(String[] args) {
	
		Scanner ler = new Scanner(System.in);
		
		double graus, Fahrenheit;
		
		System.out.printf("Informe uma temperatura em graus Celcius: ");
		graus = ler.nextDouble();
		
		Fahrenheit = graus * 1.8 + 32;
		
		System.out.printf("A temperatura em Fahrenheit é: %.2f", Fahrenheit);

	}

}
