package Exercicios_ADS4;

import java.util.Scanner;

public class Ex13 {

	//Entrar via teclado com três valores distintos. Exibir o maior deles.

		public static void main(String[] args) {
			Scanner ler = new Scanner(System.in);
			
			double valor1, valor2, valor3;
			
			System.out.printf("Digite o primeiro valor: ");
			valor1 = ler.nextDouble();
			
			System.out.printf("Digite o segundo valor: ");
			valor2 = ler.nextDouble();
			
			System.out.printf("Digite o terceiro valor: ");
			valor3 = ler.nextDouble();
			
			if (valor1 > valor2) {
				if (valor1 > valor3) {
					System.out.printf("O maior valor foi o PRIMEIRO digitado: %.0f", valor1);
					
				}else {
					System.out.printf("O maior valor foi o TERCEIRO digitado: %.0f", valor3);
				}
			}else {
				if (valor2 > valor3) {
					System.out.printf("O maior valor foi o SEGUNDO digitado: %.0f", valor2);
				
				}else {
					System.out.printf("O maior valor foi o TERCEIRO digitado: %.0f", valor3);
				}
				
			}
			
		}

	}
