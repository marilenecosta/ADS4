package Exercicios_ADS4;

import java.util.Scanner;

public class Ex42 {
	
	//Calcular e exibir a soma dos “N” primeiros valores da seqüência abaixo. 
	//O valor “N” será digitado, deverá ser positivo, mas menor que cinqüenta. 
	//Caso o valor não satisfaça a restrição, enviar mensagem de erro e solicitar o valor novamente.

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		int N;
		float Soma = 0, Y = 1;
		
		do {
		System.out.printf("Informe o tamanho da sequência (1 >= n < 50): ");
		N = ler.nextInt();
		}
		while(N < 1 || N > 49);
		
		for(int X = 0; X < N; X++) {
			Soma+= Y/(Y+1);
			Y++;
		}
		
		System.out.printf("A soma dos primeiros %d números da sequência é: %.2f", N, Soma);

	}

}
