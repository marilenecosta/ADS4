package Exercicios_ADS4;

import java.util.Scanner;

public class Ex18 {
	
	//Criar um programa para analisar a velocidade de um automóvel. Solicitar via teclado os valores da aceleração (a em m/s2), 
	//velocidade inicial (v0 em m/s) e o tempo de percurso (t em s). Calcular e exibir a velocidade final do automóvel em km/h. 
	//E exibir mensagem de acordo com a tabela.

		public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		
		double A, VI , T, VF, VKM; 
		
		System.out.printf("Digite a ACELERAÇÃO do automóvel: ");
		A = ler.nextDouble();
		
		System.out.printf("Digite a VELOCIDADE INICIAL do automóvel: ");
		VI = ler.nextDouble();
		
		System.out.printf("Digite o TEMPO do percurso: ");
		T= ler.nextDouble();
		
		VF = VI + (A * T);
		
		System.out.printf("VELOCIDADE FINAL = %.2f m/s.\n", VF);
		
VKM = (VF * 3.6);
		
		if(VKM <= 40) {
			System.out.printf("A Velocidade em km/h = %.2f.\n", VKM);
			System.out.println("Veiculo está muito LENTO!!!");
			
		}else if(VKM <= 60) {
			System.out.printf("A Velocidade em km/h = %.2f.\n", VKM);
			System.out.println("Velocidade PERMITIDA!!!");
		
		}else if(VKM<=80) {
			System.out.printf("A Velocidade em km/h = %.2f.\n", VKM);
			System.out.println("VELOCIDADE de cruzeiro!!!");
		
		}else if(VKM<=120) {
			System.out.printf("A Velocidade em km/h = %.2f.\n", VKM);
			System.out.println("Veiculo RÁPIDO!!!");
		
		}else {
			System.out.printf("Velocidade em km/h = %.2f.\n", VKM);
			System.out.println("Veiculo MUITO RÁPIDO!!!");
		}
		
	}

}
