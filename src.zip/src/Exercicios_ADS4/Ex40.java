package Exercicios_ADS4;

import java.util.Scanner;

public class Ex40 {
	
	//Exibir os vinte primeiros valores da série de Bergamaschi. A série: 1, 1, 1, 3, 5, 9, 17, ...

	public static void main(String[] args) {
		int Soma, A = 1, B = 1, C = 1;
		for(int X = 0; X < 20; X++) {
			if(X < 3) {
				System.out.printf("\n1");
			}
			else {
				Soma = A + B + C;
				System.out.printf("\n%d",(Soma));
				C = B;
				B = A;
				A = Soma;
			}
			
		}

	}

}
