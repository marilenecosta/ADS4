package Exercicios_ADS4;

import java.util.Scanner;

public class Ex01 {
	
	//Entrar via teclado com a base e a altura de um retângulo, calcular e exibir sua área.

	public static void main(String[] args) {

		Scanner ler = new Scanner(System.in);
		
		double base, altura, area;
		
		System.out.printf("Digite a medida da base: ");
		base = ler.nextDouble();
		
		System.out.printf("Digite a medida da altura: ");
		altura = ler.nextDouble();
		
		area = base * altura;
		System.out.printf("A área do retângulo é %.2f * %.2f é = %.2f", base, altura, area);
	}

}
