package Exercicios_ADS4;

import java.util.Scanner;

public class Ex11 {
	
	//Calcular e exibir a área de um retângulo, a partir dos valores da base e altura que 
	//serão digitados. Se a área for maior que 100, exibir a mensagem “Terreno grande”
	
	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		
		double base, altura, area;
		
		System.out.printf("Digite a base do retângulo: ");
		base = ler.nextDouble();
		
		System.out.printf("Digite a altura do retângulo: ");
		altura = ler.nextDouble();
		
		area = (base * altura);
		
		if (area >= 100) {
			System.out.printf("Terreno Grande!!!");
		}

	}

}
