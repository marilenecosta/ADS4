package Exercicios_ADS4;

import java.util.Scanner;

public class Ex03 {

	//A partir dos valores da base e altura de um triângulo, calcular e exibir sua área.
	
	public static void main(String[] args) {
	
		Scanner ler = new Scanner(System.in);
			
			double base, altura, area;
						
			System.out.print("Digite a base do triângulo: ");
			base = ler.nextDouble();
			
			System.out.print("Digite a altura do triângulo: ");
			altura = ler.nextDouble();
			
			area = (base * altura) / 2;
			
			System.out.printf("A área do triângulo é: %.2f", area);
			
	}

}
