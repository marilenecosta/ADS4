package Exercicios_ADS4;

import java.util.Scanner;

public class Ex22 {
	
	//Exibir o seguinte seletor de opções e em função de uma escolha, solicitar os dados necessários para o cálculo da respectiva área. 
	//Enviar mensagem de erro se o usuário escolher uma opção inexistente.
	//Encerrar o programa somente quando selecionada a opção de finalização. (Fazer esse exercício utilizando If..Else e/ou Case)
	//1 – Triângulo
	//2 – Quadrado
	//3 – Retângulo
	//4 – Círculo
	//5 – Fim de processo

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		
		int Opcao;
		double Base, Altura, Raio, Area;
		
		do {
						
			System.out.printf("Menu de Opções:\n");
			System.out.printf("Opção <1> Área de um TRIÂNGULO\n");
			System.out.printf("Opção <2> Área de um QUADRADO\n");
			System.out.printf("Opção <3> Área de um RETÂNGULO\n");
			System.out.printf("Opção <4> Área de um CÍRCULO\n");
			System.out.printf("Opção <5> Sair do Programa\n");
			System.out.printf("Digite a opcao desejada: ");
			Opcao = ler.nextInt();
			
			switch(Opcao) {
			case 1:
				
				System.out.printf("Digite a base do TRIÂNGULO: ");
				Base = ler.nextDouble();
				
				System.out.printf("Digite a altura do TRIÂNGULO: ");
				Altura = ler.nextDouble();
				
				Area = (Base * Altura) / 2;
				
				System.out.printf("A area do TRIÂNGULO é: %.2f.\n", Area);
				
				break;
				
			case 2:
				
				System.out.printf("Digite a aresta do QUADRADO: ");
				Base = ler.nextDouble();
				
				Area = Base * Base;
				
				System.out.printf("A área do QUADRADO é: %.2f.\n", Area);
				
				break;
				
			case 3:
				
				System.out.printf("Digite a base do RETÂNGULO: ");
				Base = ler.nextDouble();
				
				System.out.printf("Digite a altura do RETÂNGULO: ");
				Altura = ler.nextDouble();
				
				Area = Base * Altura;
				
				System.out.printf("A area do RETÂNGULO é: %.2f.\n", Area);
				
				break;
				
			case 4:
				
				System.out.printf("Digite o raio do CÍRCULO: ");
				Raio = ler.nextDouble();
				
				
				Area = 3.14 * (Raio * Raio);
				
				System.out.printf("A area do CÍRCULO é: %.2f.\n", Area);
				
				break;
				
			case 5:
				
				System.out.println("PROGRAMA FINALIZADO!!!");
				System.exit(0);
				
				break;
		}
		
	}while(Opcao!=5);

	}

}
