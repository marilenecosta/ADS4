package Exercicios_ADS4;

import java.util.Scanner;

public class Ex24 {
	
	//Faça um algoritmo que leia o nome, o sexo e o estado civil de uma pessoa. Caso sexo seja “F” e estado civil seja “CASADA”, 
	//solicitar o tempo de casada (anos).

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
				
				String Nome, Sexo, EstadoCivil;
				int Tempo;
				
				System.out.printf("Digite seu nome: ");
				Nome = ler.nextLine();
				
				System.out.printf("Digite seu sexo (F) para FEMININO e (M) para MASCULINO: ");
				Sexo = ler.nextLine();
				
				System.out.printf("Digite seu estado civil: ");
				EstadoCivil = ler.nextLine();
				
				if(Sexo.toUpperCase().equals("F") && EstadoCivil.toUpperCase().equals("CASADA")) {
					System.out.printf("Digite quantos anos você é CASADA: ");
					Tempo = ler.nextInt();
					System.out.printf("Nome: %s\nSexo: %s\nEstado Civil: %s\nAnos de Casamento: %d", Nome, Sexo, EstadoCivil, Tempo);
				}
				else {
					System.out.printf("Nome: %s\nSexo: %s\nEstado Civil: %s", Nome, Sexo, EstadoCivil);
				}
	
	}

}
