package Exercicios_ADS4;

import java.util.Scanner;

public class Ex19 {
	
	//Uma escola com cursos em regime semestral, realiza duas avaliações durante o semestre e calcula a média do aluno, da seguinte maneira:
	//MEDIA = (P1 + 2.P2) / 3. Fazer um programa para entrar via teclado com os valores das notas (P1 e P2) e calcular a média.
	//Exibir a situação final do aluno (“Aprovado ou Reprovado”), sabendo que a média de aprovação é igual a cinco.


	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		
		double P1, P2, Media;
		
		System.out.printf("Digite a nota da P1: ");
		P1 = ler.nextDouble();
		
		System.out.printf("Digite a nota da P2: ");
		P2 = ler.nextDouble();
		
		Media = (P1 + (2 * P2)) / 3;
		
		if(Media >= 5) 
			System.out.printf("A média é %.2f. PARABÉNS!!! Você foi APROVADO!!!", Media);
		else 
			System.out.printf("A média é %.2f. Você foi REPROVADO!!!", Media);

	}

}

