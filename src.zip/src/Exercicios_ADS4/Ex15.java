
package Exercicios_ADS4;

import java.util.Scanner;

public class Ex15 {

	//A partir de três valores que serão digitados, verificar se formam ou não um triângulo. Em caso positivo, exibir sua 
	//classificação: “Isósceles, escaleno ou eqüilátero”. Um triângulo escaleno possui todos os lados diferentes, o isósceles, 
	//dois lados iguais e o eqüilátero, todos os lados iguais. Para existir triângulo é necessário que a 
	//soma de dois lados quaisquer seja maior que o outro, isto, para os três lados.


	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		
		double A, B, C;
		
		System.out.printf("Digite o primeiro valor: ");
		A = ler.nextDouble();
		
		System.out.printf("Digite o segundo valor: ");
		B = ler.nextDouble();
		
		System.out.printf("Digite o terceiro valor: ");
		C = ler.nextDouble();
		
		if (A + B > C && A + C > B && B + C > A) {
		System.out.printf("Os 3 lados formam um triângulo!\n");

		if (A == B && A == C) {
			System.out.printf("O triângulo é EQUILATERO!!!\n");
		} else {
			if (A == B || A == C || B == C) {
				System.out.printf("O triângulo é ISOSCELES!!!\n");
			} else {
				System.out.printf("O triângulo é ESCALENO!!!\n");
			} 
		}
	} else {
			System.out.printf("Os 3 lados NÃO formam um TRIÂNGULO!!!!\n");
	}

	}

}
