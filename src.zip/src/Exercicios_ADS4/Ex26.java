package Exercicios_ADS4;

import java.util.Scanner;

public class Ex26 {
	
	//Encontrar o dobro de um número caso ele seja positivo e o seu triplo caso seja negativo, imprimindo o resultado.

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
			
			int Valor, Resultado;
			
			System.out.printf("Digite qualquer valor POSITIVO ou NEGATIVO: ");
			Valor = ler.nextInt();
			
			if(Valor < 0) {
				Resultado = (Valor * 3);
				System.out.printf("O Resultado é: %d", Resultado);
			}else {
				Resultado = (Valor * 2);
				System.out.printf("O Resultado é: %d", Resultado);
			}

	}

}
