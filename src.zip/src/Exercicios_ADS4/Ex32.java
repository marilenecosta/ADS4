package Exercicios_ADS4;

import java.util.Scanner;

public class Ex32 {
	
	//Entrar com dois valores via teclado, onde o segundo deverá ser maior que o primeiro. Caso contrário solicitar novamente apenas o segundo valor.

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
				
				int A, B;
				System.out.printf("Digite o PRIMEIRO valor:");
				A= ler.nextInt();
				
				do{	
				System.out.printf("Digite SEGUNDO valor, ele tem que ser MAIOR que o PRIMEIRO:");
				B= ler.nextInt();
				}
				while(A>=B);

	}

}
